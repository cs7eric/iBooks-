kaptcha - A kaptcha generation engine.

Please see the website for more information about this project.

http://code.google.com/p/kaptcha/

thanks!